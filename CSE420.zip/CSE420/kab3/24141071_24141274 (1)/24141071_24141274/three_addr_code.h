#ifndef THREE_ADDR_CODE_H
#define THREE_ADDR_CODE_H

#include "ast.h"
#include <fstream>
#include <string>
#include <map>

using namespace std;

class ThreeAddrCodeGenerator {
private:
    ProgramNode* ast_root;
    ofstream& outcode;
    map<string, string> symbol_to_temp;
    int temp_count;
    int label_count;

public:
    ThreeAddrCodeGenerator(ProgramNode* root, ofstream& out)
        : ast_root(root), outcode(out), temp_count(0), label_count(0) {}

    void generate() {
        if (ast_root) {
            ast_root->generate_code(outcode, symbol_to_temp, temp_count, label_count);
        }
    }

    // Helper method to get a fresh temporary variable
    string get_fresh_temp() {
        string temp = "t" + to_string(temp_count++);
        return temp;
    }

    // Helper method to get a fresh label
    string get_fresh_label() {
        string label = "L" + to_string(label_count++);
        return label;
    }

    // Map symbol to temporary variable
    void map_symbol_to_temp(const string& symbol, const string& temp) {
        symbol_to_temp[symbol] = temp;
    }

    // Get temporary variable for a symbol
    string get_temp_for_symbol(const string& symbol) {
        auto it = symbol_to_temp.find(symbol);
        if (it != symbol_to_temp.end()) {
            return it->second;
        }
        return symbol; // Return the symbol itself if no temp is assigned
    }
};

#endif // THREE_ADDR_CODE_H