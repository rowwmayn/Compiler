#ifndef SCOPE_TABLE_H
#define SCOPE_TABLE_H

#include <bits/stdc++.h>
#include "symbol_info.h"
using namespace std;

/**
 * ScopeTable implements a single scope in the symbol table hierarchy.
 * Each scope is a hash table of symbols (variables, arrays, functions).
 */
class ScopeTable {
private:
    int bucket_size;                 // Number of buckets
    vector<SymbolInfo*> table;       // Array of linked lists
    string id;                       // Unique ID for this scope
    ScopeTable* parent_scope;        // Pointer to parent scope

    // 🔹 Simplified hash function:
    // Adds up all ASCII values and takes modulo bucket_size
    unsigned long long hash_func(const string& name) const {
        unsigned long long sum = 0;
        for (char c : name) sum += (unsigned long long)c;
        return sum % bucket_size;
    }

public:
    // Constructor
    ScopeTable(int n = 20, string id = "1", ScopeTable* parent = nullptr)
        : bucket_size(n), table(n, nullptr), id(id), parent_scope(parent) {}

    // Destructor – frees memory for all symbols in this scope
    ~ScopeTable() {
        for (auto head : table) {
            while (head) {
                SymbolInfo* temp = head;
                head = head->get_next();
                delete temp;
            }
        }
    }

    // --- Getters ---
    string get_id() const { return id; }
    ScopeTable* get_parent() const { return parent_scope; }

    // --- Insert symbol ---
    bool Insert(const string& name, const string& type) {
        unsigned long long index = hash_func(name);
        SymbolInfo* head = table[index];

        // Check duplicate symbol in this scope
        for (SymbolInfo* temp = head; temp != nullptr; temp = temp->get_next()) {
            if (temp->get_name() == name) {
                cout << "\t" << name << " already exists in ScopeTable# " << id << endl;
                return false;
            }
        }

        // Insert new symbol at head of linked list
        SymbolInfo* newSym = new SymbolInfo(name, type);
        newSym->set_next(head);
        table[index] = newSym;

        cout << "\tInserted " << name << " in ScopeTable# " << id
             << " at position " << index << ",0" << endl;
        return true;
    }

    // --- Lookup symbol ---
    SymbolInfo* Lookup(const string& name) {
        unsigned long long index = hash_func(name);
        SymbolInfo* temp = table[index];
        int pos = 0;

        while (temp) {
            if (temp->get_name() == name) {
                cout << "\t" << name << " found in ScopeTable# " << id
                     << " at position " << index << "," << pos << endl;
                return temp;
            }
            temp = temp->get_next();
            pos++;
        }
        return nullptr;
    }

    // --- Delete symbol ---
    bool Delete(const string& name) {
        unsigned long long index = hash_func(name);
        SymbolInfo* temp = table[index];
        SymbolInfo* prev = nullptr;
        int pos = 0;

        while (temp) {
            if (temp->get_name() == name) {
                if (prev) prev->set_next(temp->get_next());
                else table[index] = temp->get_next();

                cout << "\tDeleted " << name << " from ScopeTable# " << id
                     << " at position " << index << "," << pos << endl;
                delete temp;
                return true;
            }
            prev = temp;
            temp = temp->get_next();
            pos++;
        }

        cout << "\tNot found " << name << " in ScopeTable# " << id << endl;
        return false;
    }

    // --- Print this scope table ---
    void Print(ostream& out = cout) const {
        out << "\nScopeTable# " << id << endl;
        for (int i = 0; i < bucket_size; i++) {
            out << i << " -->";
            SymbolInfo* temp = table[i];
            while (temp) {
                out << " <" << temp->get_name() << "," << temp->get_type() << ">";
                temp = temp->get_next();
            }
            out << endl;
        }
    }
};

#endif // SCOPE_TABLE_H
