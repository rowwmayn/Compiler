#ifndef SYMBOL_INFO_H
#define SYMBOL_INFO_H

#include <bits/stdc++.h>
using namespace std;

class symbol_info {
private:
    string name;        // Symbol name (identifier)
    string type;        // Token type (e.g., ID, KEYWORD, CONST_INT, etc.)
    string dataType;    // Semantic type (int, float, void, etc.)

    // Extra attributes
    string idCategory;  // "variable", "array", or "function"
    int arraySize;      // For arrays

    vector<string> paramTypes;  // For function parameters
    int paramCount;             // Number of parameters
    string returnType;          // For function return type

    symbol_info* next;          // For linked list in hash bucket

public:
    // Constructor
    symbol_info(string name = "", string type = "")
        : name(name), type(type), dataType(""), idCategory(""),
          arraySize(-1), paramCount(0), returnType(""), next(nullptr) {}

    // --- Basic Getters/Setters ---
    string get_name() const { return name; }
    string get_type() const { return type; }
    void set_name(const string& n) { name = n; }
    void set_type(const string& t) { type = t; }

    // --- Linked list accessors ---
    void set_next(symbol_info* n) { next = n; }
    symbol_info* get_next() const { return next; }

    // --- Semantic info setters/getters ---
    void set_dataType(const string& t) { dataType = t; }
    string get_dataType() const { return dataType; }

    void set_idCategory(const string& cat) { idCategory = cat; }
    string get_idCategory() const { return idCategory; }

    void set_arraySize(int size) { arraySize = size; }
    int get_arraySize() const { return arraySize; }

    void set_returnType(const string& ret) { returnType = ret; }
    string get_returnType() const { return returnType; }

    void set_paramTypes(const vector<string>& params) {
        paramTypes = params;
        paramCount = (int)params.size();
    }

    vector<string> get_paramTypes() const { return paramTypes; }
    int get_paramCount() const { return paramCount; }

    // Add one parameter type
    void add_paramType(const string& t) {
        paramTypes.push_back(t);
        paramCount = (int)paramTypes.size();
    }

    // Debug string for printing
    string infoString() const {
        string s = "<" + name + "," + type;
        if (!dataType.empty()) s += "," + dataType;
        if (idCategory == "array")
            s += ",size=" + to_string(arraySize);
        else if (idCategory == "function") {
            s += ",ret=" + returnType + ",params=";
            for (int i = 0; i < paramTypes.size(); i++) {
                s += paramTypes[i];
                if (i + 1 < paramTypes.size()) s += ",";
            }
        }
        s += ">";
        return s;
    }

    ~symbol_info() {
        // No dynamic members except `next`, which is handled by ScopeTable
    }
};

#endif // SYMBOL_INFO_H
