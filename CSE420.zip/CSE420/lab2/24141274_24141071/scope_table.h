#ifndef SCOPE_TABLE_H
#define SCOPE_TABLE_H

#include "symbol_info.h"
#include <bits/stdc++.h>
using namespace std;

class scope_table {
private:
    int bucket_count;
    int unique_id;
    scope_table *parent_scope;
    vector<list<symbol_info*>> table;

    int hash_function(const string &name) const {
        unsigned long h = 0;
        for (char c : name) h = (h * 17 + (unsigned char)c);
        return (int)(h % bucket_count);
    }

public:
    scope_table(int buckets = 10, int id = 1, scope_table *parent = nullptr)
        : bucket_count(buckets), unique_id(id), parent_scope(parent) {
        table.resize(bucket_count);
    }

    ~scope_table() {  // destructor to free all symbol_info pointers
        for (int i = 0; i < bucket_count; ++i) {
            for (symbol_info *s : table[i]) {
                delete s;
            }
            table[i].clear();
        }
    }

    scope_table* get_parent_scope() const { return parent_scope; }
    int get_unique_id() const { return unique_id; }

    // Insert symbol into THIS scope only. If same name already exists here -> return false.
    bool insert_in_scope(symbol_info* sym) {
        string name = sym->get_name();
        int idx = hash_function(name);
        for (auto existing : table[idx]) {
            if (existing->get_name() == name) {
                return false; // already in this scope
            }
        }
        table[idx].push_back(sym);
        return true;
    }

    // Lookup in THIS scope only. Returns pointer if found, nullptr otherwise.
    symbol_info* lookup_in_scope(const string &name) {
        int idx = hash_function(name);
        for (auto s : table[idx]) {
            if (s->get_name() == name) return s;
        }
        return nullptr;
    }

    // Delete from THIS scope only by name.
    bool delete_from_scope(const string &name) {
        int idx = hash_function(name);
        for (auto it = table[idx].begin(); it != table[idx].end(); ++it) {
            if ((*it)->get_name() == name) {
                delete *it;
                table[idx].erase(it);
                return true;
            }
        }
        return false;
    }

    // Print scope table in the lab-specified exact format to given ofstream
    void print_scope_table(ofstream &out) {
        out << "ScopeTable # " << unique_id << endl;
        for (int i = 0; i < bucket_count; ++i) {
            if (!table[i].empty()) {
                out << i << " --> " << endl;
                for (auto s : table[i]) {
                    // first line: < name : LEXTYPE >
                    out << "< " << s->get_name() << " : " << s->get_lex_type() << " >" << endl;

                    // semantic lines
                    string sem = s->get_symbol_type();
                    if (sem == "Function Definition") {
                        out << "Function Definition" << endl;
                        out << "Return Type: " << s->get_return_type() << endl;
                        out << "Number of Parameters: " << s->get_size() << endl;
                        out << "Parameter Details: ";
                        vector<string> pd = s->get_param_decls();
                        for (size_t k = 0; k < pd.size(); ++k) {
                            out << pd[k];
                            if (k + 1 < pd.size()) out << ", ";
                        }
                        out << endl;
                    } else if (sem == "Array") {
                        out << "Array" << endl;
                        out << "Type: " << s->get_return_type() << endl;
                        out << "Size: " << s->get_size() << endl;
                    } else if (sem == "Variable") {
                        out << "Variable" << endl;
                        out << "Type: " << s->get_return_type() << endl;
                    } else {
                        // unknown semantic, still print lexicographic type and any return type
                        out << sem << endl;
                        if (!s->get_return_type().empty()) {
                            out << "Type: " << s->get_return_type() << endl;
                        }
                    }
                    out << endl;
                }
            }
        }
    }
};

#endif
