#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

#include "scope_table.h"
#include <bits/stdc++.h>
using namespace std;

class symbol_table {
private:
    scope_table *current_scope;
    int bucket_count;
    int next_scope_id;
    ofstream *outlog;

public:
    symbol_table(int buckets = 10, ofstream *log = nullptr) {
        bucket_count = buckets;
        current_scope = nullptr;
        next_scope_id = 1;
        outlog = log;
        current_scope = new scope_table(bucket_count, next_scope_id++, nullptr);
    }

    ~symbol_table() {
        while (current_scope) exit_scope();
    }

    void enter_scope() {
        scope_table *new_scope = new scope_table(bucket_count, next_scope_id++, current_scope);
        current_scope = new_scope;
        if (outlog) {
            *outlog << "New ScopeTable with ID " << current_scope->get_unique_id() << " created" << endl << endl;
        }
    }

    void exit_scope() {
        if (!current_scope) {
            if (outlog) *outlog << "No scope to exit." << endl << endl;
            return;
        }
        if (outlog) *outlog << "Scopetable with ID " << current_scope->get_unique_id() << " removed" << endl << endl;
        scope_table *temp = current_scope;
        current_scope = current_scope->get_parent_scope();
        delete temp;
    }

    // insert symbol into current scope only
    bool insert(symbol_info* sym) {
        if (!current_scope) {
            if (outlog) *outlog << "No active scope to insert " << sym->get_name() << endl;
            return false;
        }
        bool ok = current_scope->insert_in_scope(sym);
        if (!ok) {
            if (outlog) *outlog << "Identifier " << sym->get_name() << " already exists in current ScopeTable" << endl << endl;
        }
        return ok;
    }

    // lookup name in current scope then parents
    symbol_info* lookup(const string &name) {
        scope_table *temp = current_scope;
        while (temp) {
            symbol_info *s = temp->lookup_in_scope(name);
            if (s) return s;
            temp = temp->get_parent_scope();
        }
        return nullptr;
    }

    // remove name from current scope
    bool remove(const string &name) {
        if (!current_scope) return false;
        bool ok = current_scope->delete_from_scope(name);
        if (!ok && outlog) *outlog << "Identifier " << name << " not found in current ScopeTable" << endl << endl;
        return ok;
    }

    void print_current_scope() {
        if (!current_scope) {
            if (outlog) *outlog << "No active scope." << endl;
            return;
        }
        current_scope->print_scope_table(*outlog);
    }

    // print all scope tables from current down to global (the stack order - current first)
    void print_all_scopes() {
        if (!outlog) return;
        *outlog << "################################" << endl << endl;
        // print from current up to global such that sample shows current first then parent...
        scope_table* temp = current_scope;
        while (temp) {
            temp->print_scope_table(*outlog);
            temp = temp->get_parent_scope();
        }
        *outlog << "################################" << endl << endl;
    }
};

#endif
