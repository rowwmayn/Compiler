#ifndef SYMBOL_INFO_H
#define SYMBOL_INFO_H

#include <bits/stdc++.h>
using namespace std;

class symbol_info {
private:
    string name;                // identifier name
    string lex_type;            // lexical token type (ID, CONST_INT, etc.)
    string symbol_type;         // semantic kind: "Variable", "Array", "Function Definition", etc.
    string return_type;         // data type for variable / return type for function
    vector<string> param_decls; // for functions: "int a", "float b", ...
    int size;                   // array size or number of parameters (kept for convenience)

public:
    symbol_info(string name = "", string lex_type = "") {
        this->name = name;
        this->lex_type = lex_type;
        this->symbol_type = "NAN";
        this->return_type = "";
        this->size = 0;
    }

    // getters
    string get_name() const { return name; }
    string get_lex_type() const { return lex_type; }
    string get_symbol_type() const { return symbol_type; }
    string get_return_type() const { return return_type; }
    int get_size() const { return size; }
    vector<string> get_param_decls() const { return param_decls; }

    // setters
    void set_name(const string &s) { name = s; }
    void set_lex_type(const string &s) { lex_type = s; }
    void set_symbol_type(const string &s) { symbol_type = s; }
    void set_return_type(const string &s) { return_type = s; }
    void set_size(int n) { size = n; }

    // add parameter declaration string like "int a"
    void add_param_decl(const string &decl) {
        param_decls.push_back(decl);
        size = (int)param_decls.size();
    }
};

#endif
