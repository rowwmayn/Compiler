%{
#include "symbol_info.h"
#include "symbol_table.h"
#include <bits/stdc++.h>
using namespace std;

#define YYSTYPE symbol_info*

int yyparse(void);
int yylex(void);
extern FILE *yyin;

ofstream outlog;
int lines = 1;

symbol_table st(10, &outlog);

// temporary storage for function parameters (we store symbol_info* for each parameter)
vector<symbol_info*> params;
int param_count = 0;

void yyerror(char *s) {
    outlog << "At line " << lines << " " << s << endl << endl;
    st.~symbol_table();
}
%}

%token IF ELSE FOR WHILE DO BREAK INT CHAR FLOAT DOUBLE VOID RETURN SWITCH CASE DEFAULT CONTINUE PRINTLN
%token ADDOP MULOP INCOP DECOP RELOP ASSIGNOP LOGICOP NOT LPAREN RPAREN LCURL RCURL LTHIRD RTHIRD COMMA SEMICOLON
%token CONST_INT CONST_FLOAT ID

%nonassoc IFX
%nonassoc ELSE

%%

start : program
    {
        outlog << "At line no: " << lines << " start : program " << endl << endl;
        outlog << "Symbol Table" << endl << endl;
        st.print_all_scopes();
    }
    ;

program : program unit
    {
        outlog << "At line no: " << lines << " program : program unit " << endl << endl;
        outlog << $1->get_name() << "\n" << $2->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "\n" + $2->get_name(), "program");
    }
    | unit
    {
        outlog << "At line no: " << lines << " program : unit " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "program");
    }
    ;

unit : var_declaration
    {
        outlog << "At line no: " << lines << " unit : var_declaration " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "unit");
    }
    | func_definition
    {
        outlog << "At line no: " << lines << " unit : func_definition " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "unit");
    }
    ;

func_definition
    : type_specifier ID LPAREN parameter_list RPAREN compound_statement
    {
        // $2 is function symbol_info (lex-type ID object). We add semantic data and insert in current (global) scope.
        $2->set_symbol_type("Function Definition");
        $2->set_return_type($1->get_name());
        // transfer params (symbol_info* in global temp vector) into $2 as strings "type name"
        for (auto p : params) {
            string decl = p->get_return_type() + " " + p->get_name();
            $2->add_param_decl(decl);
        }
        $2->set_size(param_count);
        // insert function into current scope (usually global)
        st.insert($2);
        // function body already handled: params were inserted into function scope at LCURL (see compound_statement)
        // clear params only here to avoid double-deleting (the param objects were inserted into scope as new pointers)
        params.clear();
        param_count = 0;
    }
    |
    type_specifier ID LPAREN RPAREN compound_statement
    {
        $2->set_symbol_type("Function Definition");
        $2->set_return_type($1->get_name());
        $2->set_size(0);
        st.insert($2);
    }
    ;

parameter_list
    : parameter_list COMMA type_specifier ID
    {
        outlog << "At line no: " << lines << " parameter_list : parameter_list COMMA type_specifier ID " << endl << endl;
        outlog << $1->get_name() << "," << $3->get_name() << " " << $4->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "," + $3->get_name() + " " + $4->get_name(), "parameter_list");

        // mark $4 as a variable param and store type
        $4->set_symbol_type("Variable");
        $4->set_return_type($3->get_name());
        params.push_back($4);
        param_count++;
    }
    | parameter_list COMMA type_specifier
    {
        outlog << "At line no: " << lines << " parameter_list : parameter_list COMMA type_specifier " << endl << endl;
        outlog << $1->get_name() << "," << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "," + $3->get_name(), "parameter_list");
    }
    | type_specifier ID
    {
        outlog << "At line no: " << lines << " parameter_list : type_specifier ID " << endl << endl;
        outlog << $1->get_name() << " " << $2->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + " " + $2->get_name(), "parameter_list");

        $2->set_symbol_type("Variable");
        $2->set_return_type($1->get_name());
        params.push_back($2);
        param_count++;
    }
    | type_specifier
    {
        outlog << "At line no: " << lines << " parameter_list : type_specifier " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "parameter_list");
    }
    ;

compound_statement
    : LCURL
    {
        // entering a new scope
        st.enter_scope();

        // if this compound_statement is a function body and parameters are pending,
        // insert all param symbols into the new (current) scope
        if (param_count > 0 && !params.empty()) {
            for (auto p : params) {
                // params vector contains pointers to symbol_info created in parser actions.
                // We must create new symbol_info objects for insertion into scope (to avoid double delete).
                symbol_info *param_copy = new symbol_info(p->get_name(), p->get_lex_type());
                param_copy->set_symbol_type("Variable");
                param_copy->set_return_type(p->get_return_type());
                st.insert(param_copy);
            }
            // We DO NOT delete original param pointers here because they were produced by yylex
            // and are tracked by 'params' vector which will be cleared by func_definition action.
        }
    }
    statements RCURL
    {
        outlog << "At line no: " << lines << " compound_statement : LCURL statements RCURL " << endl << endl;
        outlog << "{\n" << $2->get_name() << "\n}" << endl << endl;
        $$ = new symbol_info("{\n" + $2->get_name() + "\n}", "compound_statement");

        // print the symbol table (current state) then exit this scope
        st.print_all_scopes();
        st.exit_scope();
    }
    | LCURL RCURL
    {
        outlog << "At line no: " << lines << " compound_statement : LCURL RCURL " << endl << endl;
        outlog << "{\n}" << endl << endl;
        $$ = new symbol_info("{\n}", "compound_statement");
    }
    ;

var_declaration
    : type_specifier declaration_list SEMICOLON
    {
        outlog << "At line no: " << lines << " var_declaration : type_specifier declaration_list SEMICOLON " << endl << endl;
        outlog << $1->get_name() << " " << $2->get_name() << ";" << endl << endl;
        $$ = new symbol_info($1->get_name() + " " + $2->get_name() + ";", "var_declaration");

        // parse comma-separated declarations from $2->get_name()
        string s = $2->get_name();
        string token;
        stringstream ss(s);
        while (getline(ss, token, ',')) {
            // token might be "id" or "id[CONST]"
            size_t l = token.find('[');
            if (l != string::npos) {
                size_t r = token.find(']');
                string name = token.substr(0, l);
                string sz_str = token.substr(l + 1, r - l - 1);
                int sz = stoi(sz_str);
                if (sz <= 0) {
                    outlog << "Error at line " << lines 
                           << ": Array '" << name << "' has invalid size " << sz 
                           << ". Array size must be positive." << endl << endl;
                    // invalid array
                    continue;
                }
                
                symbol_info *sym = new symbol_info(name, "ID");
                sym->set_symbol_type("Array");
                sym->set_return_type($1->get_name());
                sym->set_size(sz);
                st.insert(sym);
            } else {
                string name = token;
                symbol_info *sym = new symbol_info(name, "ID");
                sym->set_symbol_type("Variable");
                sym->set_return_type($1->get_name());
                st.insert(sym);
            }
        }
    }
    ;

type_specifier
    : INT
    {
        outlog << "At line no: " << lines << " type_specifier : INT " << endl << endl;
        outlog << "int" << endl << endl;
        $$ = new symbol_info("int", "type_specifier");
    }
    | FLOAT
    {
        outlog << "At line no: " << lines << " type_specifier : FLOAT " << endl << endl;
        outlog << "float" << endl << endl;
        $$ = new symbol_info("float", "type_specifier");
    }
    | VOID
    {
        outlog << "At line no: " << lines << " type_specifier : VOID " << endl << endl;
        outlog << "void" << endl << endl;
        $$ = new symbol_info("void", "type_specifier");
    }
    ;

declaration_list
    : declaration_list COMMA ID
    {
        outlog << "At line no: " << lines << " declaration_list : declaration_list COMMA ID " << endl << endl;
        outlog << $1->get_name() << "," << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "," + $3->get_name(), "declaration_list");
    }
    | declaration_list COMMA ID LTHIRD CONST_INT RTHIRD
    {
        outlog << "At line no: " << lines << " declaration_list : declaration_list COMMA ID LTHIRD CONST_INT RTHIRD " << endl << endl;
        outlog << $1->get_name() << "," << $3->get_name() << "[" << $5->get_name() << "]" << endl << endl;
        $$ = new symbol_info($1->get_name() + "," + $3->get_name() + "[" + $5->get_name() + "]", "declaration_list");
    }
    | ID
    {
        outlog << "At line no: " << lines << " declaration_list : ID " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "declaration_list");
    }
    | ID LTHIRD CONST_INT RTHIRD
    {
        outlog << "At line no: " << lines << " declaration_list : ID LTHIRD CONST_INT RTHIRD " << endl << endl;
        outlog << $1->get_name() << "[" << $3->get_name() << "]" << endl << endl;
        $$ = new symbol_info($1->get_name() + "[" + $3->get_name() + "]", "declaration_list");
    }
    ;

statements
    : statement
    {
        outlog << "At line no: " << lines << " statements : statement " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "statements");
    }
    | statements statement
    {
        outlog << "At line no: " << lines << " statements : statements statement " << endl << endl;
        outlog << $1->get_name() << "\n" << $2->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "\n" + $2->get_name(), "statements");
    }
    ;

statement
    : var_declaration
    {
        outlog << "At line no: " << lines << " statement : var_declaration " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "statement");
    }
    | expression_statement
    {
        outlog << "At line no: " << lines << " statement : expression_statement " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "statement");
    }
    | compound_statement
    {
        outlog << "At line no: " << lines << " statement : compound_statement " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "statement");
    }
    | FOR LPAREN expression_statement expression_statement expression RPAREN statement
    {
        outlog << "At line no: " << lines << " statement : FOR LPAREN expression_statement expression_statement expression RPAREN statement " << endl << endl;
        outlog << "for(" << $3->get_name() << $4->get_name() << $5->get_name() << ")\n" << $7->get_name() << endl << endl;
        $$ = new symbol_info("for(" + $3->get_name() + $4->get_name() + $5->get_name() + ")\n" + $7->get_name(), "statement");
    }
    | IF LPAREN expression RPAREN statement %prec IFX
    {
        outlog << "At line no: " << lines << " statement : IF LPAREN expression RPAREN statement " << endl << endl;
        outlog << "if(" << $3->get_name() << ")\n" << $5->get_name() << endl << endl;
        $$ = new symbol_info("if(" + $3->get_name() + ")\n" + $5->get_name(), "statement");
    }
    | IF LPAREN expression RPAREN statement ELSE statement
    {
        outlog << "At line no: " << lines << " statement : IF LPAREN expression RPAREN statement ELSE statement " << endl << endl;
        outlog << "if(" << $3->get_name() << ")\n" << $5->get_name() << "\nelse\n" << $7->get_name() << endl << endl;
        $$ = new symbol_info("if(" + $3->get_name() + ")\n" + $5->get_name() + "\nelse\n" + $7->get_name(), "statement");
    }
    | WHILE LPAREN expression RPAREN statement
    {
        outlog << "At line no: " << lines << " statement : WHILE LPAREN expression RPAREN statement " << endl << endl;
        outlog << "while(" << $3->get_name() << ")\n" << $5->get_name() << endl << endl;
        $$ = new symbol_info("while(" + $3->get_name() + ")\n" + $5->get_name(), "statement");
    }
    | PRINTLN LPAREN ID RPAREN SEMICOLON
    {
        outlog << "At line no: " << lines << " statement : PRINTLN LPAREN ID RPAREN SEMICOLON " << endl << endl;
        outlog << "printf(" << $3->get_name() << ");" << endl << endl;
        $$ = new symbol_info("printf(" + $3->get_name() + ");", "statement");
    }
    | RETURN expression SEMICOLON
    {
        outlog << "At line no: " << lines << " statement : RETURN expression SEMICOLON " << endl << endl;
        outlog << "return " << $2->get_name() << ";" << endl << endl;
        $$ = new symbol_info("return " + $2->get_name() + ";", "statement");
    }
    ;

expression_statement
    : SEMICOLON
    {
        outlog << "At line no: " << lines << " expression_statement : SEMICOLON " << endl << endl;
        outlog << ";" << endl << endl;
        $$ = new symbol_info(";", "expression_statement");
    }
    | expression SEMICOLON
    {
        outlog << "At line no: " << lines << " expression_statement : expression SEMICOLON " << endl << endl;
        outlog << $1->get_name() << ";" << endl << endl;
        $$ = new symbol_info($1->get_name() + ";", "expression_statement");
    }
    ;

variable
    : ID
    {
        outlog << "At line no: " << lines << " variable : ID " << endl << endl;
        outlog << $1->get_name() << endl << endl;

        // semantic check: variable must be declared somewhere
        symbol_info *found = st.lookup($1->get_name());
        if (!found) {
            outlog << "Undeclared identifier " << $1->get_name() << " used at line " << lines << endl << endl;
        }

        $$ = new symbol_info($1->get_name(), "variable");
    }
    | ID LTHIRD expression RTHIRD
    {
        outlog << "At line no: " << lines << " variable : ID LTHIRD expression RTHIRD " << endl << endl;
        outlog << $1->get_name() << "[" << $3->get_name() << "]" << endl << endl;

        symbol_info *found = st.lookup($1->get_name());
        if (!found) {
            outlog << "Undeclared identifier " << $1->get_name() << " used at line " << lines << endl << endl;
        }

        $$ = new symbol_info($1->get_name() + "[" + $3->get_name() + "]", "variable");
    }
    ;

expression
    : logic_expression
    {
        outlog << "At line no: " << lines << " expression : logic_expression " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "expression");
    }
    | variable ASSIGNOP logic_expression
    {
        outlog << "At line no: " << lines << " expression : variable ASSIGNOP logic_expression " << endl << endl;
        outlog << $1->get_name() << "=" << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "=" + $3->get_name(), "expression");
    }
    ;

logic_expression
    : rel_expression
    {
        outlog << "At line no: " << lines << " logic_expression : rel_expression " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "logic_expression");
    }
    | rel_expression LOGICOP rel_expression
    {
        outlog << "At line no: " << lines << " logic_expression : rel_expression LOGICOP rel_expression " << endl << endl;
        outlog << $1->get_name() << $2->get_name() << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + $2->get_name() + $3->get_name(), "logic_expression");
    }
    ;

rel_expression
    : simple_expression
    {
        outlog << "At line no: " << lines << " rel_expression : simple_expression " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "rel_expression");
    }
    | simple_expression RELOP simple_expression
    {
        outlog << "At line no: " << lines << " rel_expression : simple_expression RELOP simple_expression " << endl << endl;
        outlog << $1->get_name() << $2->get_name() << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + $2->get_name() + $3->get_name(), "rel_expression");
    }
    ;

simple_expression
    : term
    {
        outlog << "At line no: " << lines << " simple_expression : term " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "simple_expression");
    }
    | simple_expression ADDOP term
    {
        outlog << "At line no: " << lines << " simple_expression : simple_expression ADDOP term " << endl << endl;
        outlog << $1->get_name() << $2->get_name() << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + $2->get_name() + $3->get_name(), "simple_expression");
    }
    ;

term
    : unary_expression
    {
        outlog << "At line no: " << lines << " term : unary_expression " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "term");
    }
    | term MULOP unary_expression
    {
        outlog << "At line no: " << lines << " term : term MULOP unary_expression " << endl << endl;
        outlog << $1->get_name() << $2->get_name() << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + $2->get_name() + $3->get_name(), "term");
    }
    ;

unary_expression
    : ADDOP unary_expression
    {
        outlog << "At line no: " << lines << " unary_expression : ADDOP unary_expression " << endl << endl;
        outlog << $1->get_name() << $2->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + $2->get_name(), "unary_expression");
    }
    | NOT unary_expression
    {
        outlog << "At line no: " << lines << " unary_expression : NOT unary_expression " << endl << endl;
        outlog << "!" << $2->get_name() << endl << endl;
        $$ = new symbol_info("!" + $2->get_name(), "unary_expression");
    }
    | factor
    {
        outlog << "At line no: " << lines << " unary_expression : factor " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "unary_expression");
    }
    ;

factor
    : variable
    {
        outlog << "At line no: " << lines << " factor : variable " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "factor");
    }
    | ID LPAREN argument_list RPAREN
    {
        outlog << "At line no: " << lines << " factor : ID LPAREN argument_list RPAREN " << endl << endl;
        outlog << $1->get_name() << "(" << $3->get_name() << ")" << endl << endl;

        // check function declaration exists
        symbol_info *fn = st.lookup($1->get_name());
        if (!fn) {
            outlog << "Undeclared function " << $1->get_name() << " used at line " << lines << endl << endl;
        } else {
            // optionally, we could check param count vs argument_list count
        }

        $$ = new symbol_info($1->get_name() + "(" + $3->get_name() + ")", "factor");
    }
    | LPAREN expression RPAREN
    {
        outlog << "At line no: " << lines << " factor : LPAREN expression RPAREN " << endl << endl;
        outlog << "(" << $2->get_name() << ")" << endl << endl;
        $$ = new symbol_info("(" + $2->get_name() + ")", "factor");
    }
    | CONST_INT
    {
        outlog << "At line no: " << lines << " factor : CONST_INT " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "factor");
    }
    | CONST_FLOAT
    {
        outlog << "At line no: " << lines << " factor : CONST_FLOAT " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "factor");
    }
    | variable INCOP
    {
        outlog << "At line no: " << lines << " factor : variable INCOP " << endl << endl;
        outlog << $1->get_name() << "++" << endl << endl;
        $$ = new symbol_info($1->get_name() + "++", "factor");
    }
    | variable DECOP
    {
        outlog << "At line no: " << lines << " factor : variable DECOP " << endl << endl;
        outlog << $1->get_name() << "--" << endl << endl;
        $$ = new symbol_info($1->get_name() + "--", "factor");
    }
    ;

argument_list
    : arguments
    {
        outlog << "At line no: " << lines << " argument_list : arguments " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "argument_list");
    }
    |
    {
        outlog << "At line no: " << lines << " argument_list :  " << endl << endl;
        outlog << "" << endl << endl;
        $$ = new symbol_info("", "argument_list");
    }
    ;

arguments
    : arguments COMMA logic_expression
    {
        outlog << "At line no: " << lines << " arguments : arguments COMMA logic_expression " << endl << endl;
        outlog << $1->get_name() << "," << $3->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name() + "," + $3->get_name(), "arguments");
    }
    | logic_expression
    {
        outlog << "At line no: " << lines << " arguments : logic_expression " << endl << endl;
        outlog << $1->get_name() << endl << endl;
        $$ = new symbol_info($1->get_name(), "arguments");
    }
    ;

%%

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cout << "Please input file name" << endl;
        return 0;
    }
    yyin = fopen(argv[1], "r");
    outlog.open("24141274_24141071.txt", ios::trunc);
    st.enter_scope(); // global scope

    if (yyin == NULL) {
        cout << "Couldn't open file" << endl;
        return 0;
    }

    yyparse();

    outlog << "Total lines: " << lines;
    outlog.close();
    fclose(yyin);
    return 0;
}
